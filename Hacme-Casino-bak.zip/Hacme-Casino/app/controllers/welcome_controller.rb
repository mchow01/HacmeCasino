class WelcomeController < ApplicationController
  layout "standard-layout"
  def index

  end
end
