require "casino/deck"
class BlackjackDeck < Deck
end