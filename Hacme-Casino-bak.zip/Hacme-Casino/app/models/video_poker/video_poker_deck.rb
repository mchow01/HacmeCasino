require 'casino/deck'
class VideoPokerDeck < Deck
end