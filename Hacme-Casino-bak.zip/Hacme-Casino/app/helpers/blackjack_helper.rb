module BlackjackHelper
  include GameHelper
end
