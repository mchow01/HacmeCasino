require File.dirname(__FILE__) + '/../../test_helper'

class RouletteWheelTest < Test::Unit::TestCase
  def test_initalize
#    RouletteWheel.new()
  end

  def test_spin
#    result = RouletteWheel.new().spin()
#    assert result.number >= -1
#    assert result.number <= 36
#    assert result.color =~ /^GREEN|RED|BLACK/
  end

end